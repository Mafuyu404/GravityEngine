package cc.sighs.gravityengine.gravity.collision;
import cc.sighs.gravityengine.api.math.Vec3d;
import cc.sighs.gravityengine.gravity.GravityFrame;
import cc.sighs.gravityengine.gravity.collision.provider.*;
import cc.sighs.gravityengine.gravity.kinematic.*;
import cc.sighs.gravityengine.gravity.kinematic.geometry.OrientedBox;
import cc.sighs.gravityengine.gravity.runtime.GravityOperationState;
import cc.sighs.gravityengine.math.geometry.*;
import java.util.*;
public class RemainingAudit {
 static ObbQueryContext context(){var c=new ObbQueryContext();c.setWorkTracker(new CollisionWorkTracker(CollisionWorkBudget.defaults()));return c;}
 static Aabb3d box(Vec3d c,double h){return new Aabb3d(c.x()-h,c.y()-h,c.z()-h,c.x()+h,c.y()+h,c.z()+h);}
 public static void main(String[] args){
  var time=KinematicStepContext.fullTick(100,1);
  var corridor=new Aabb3d(-1,-1,-1,1,1,1);
  var large=SceneFixtures.dynamicObstacle(1,1,0,Vec3d.ZERO,100,Vec3d.ZERO,Vec3d.ZERO,100,1,1);
  try{DynamicEntityBroadphasePolicy.validateProviderPublication(large,new ExternalRigidCollisionQuery(corridor,DynamicEntityBroadphasePolicy.candidateQueryBounds(corridor),time),time);System.out.println("LARGE accepted");}
  catch(CollisionSceneCoverageException e){System.out.println("LARGE stationary intersecting primitive rejected: "+e.getMessage());}
  var motion=new RigidMotionSnapshot(new RigidPose(Vec3d.ZERO,OrthonormalFrame3d.IDENTITY),Vec3d.ZERO,new Vec3d(0,1,0),100,1,0,1);
  var tr=new SupportMotionTrajectory(motion,new Vec3d(3,0,0));
  Vec3d chord=tr.displacement(0,1);
  var transport=new SupportTransport(chord,Vec3d.ZERO,Vec3d.ZERO,Optional.of(tr),1,1,100);
  var runtime=new GravityOperationState();
  try(var ignored=runtime.openMove(GravityFrame.DEFAULT,100)){
   runtime.stageEngineSupportTransport(transport);runtime.consumeEngineSupportTransport();
   System.out.println("CONSUMED pending="+runtime.pendingEngineSupportTransport().isPresent()+", selectableTrajectory="+runtime.engineSupportTransport().orElseThrow().hasRotationalTrajectory());
   Vec3d actorCenter=tr.positionAt(1).add(new Vec3d(0,1,0));
   Vec3d loopMid=tr.displacement(0,.5).subtract(chord.multiply(.5));
   var obstacle=new BlockObstacle(new CellPos(0,0,0),box(actorCenter.add(loopMid),.03));
   var scene=SceneFixtures.scene(100,1,1,List.of(obstacle),List.of());
   var request=new KinematicMoveRequest(Vec3d.ZERO,OwnedMotion.ZERO,KinematicMoveRequest.Channel.SELF);
   var actor=OrientedBox.axisAligned(box(actorCenter,.03));
   var plain=GravityCharacterRoute.resolve(actor,request,GravityFrame.DEFAULT,scene,context(),StepUpIntent.disabled());
   var replay=SupportedCharacterRoute.resolve(actor,request,GravityFrame.DEFAULT,scene,context(),StepUpIntent.disabled(),transport);
   System.out.println("ZERO SECOND REQUEST ordinary="+plain.resolvedMovement()+", stale-trajectory="+replay.resolvedMovement()+", blocked="+replay.blockedTangent()+", indeterminate="+replay.indeterminate());
  }
  var constrained=ContactConstraintProjector.project(Vec3d.ZERO,List.of(new ContactConstraintProjector.Constraint(new Vec3d(0,1,0),.1))).projectedVectorOrNull();
  System.out.println("ELEVATOR projectedWorldVelocity="+constrained+", nextWorldVelocityPlusCarry="+constrained.add(new Vec3d(0,.1,0)));
 }
}

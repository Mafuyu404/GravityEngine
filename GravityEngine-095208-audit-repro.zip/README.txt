095208 审查反例（不是游戏端到端验收）

RemainingAudit.java 使用当前 common 的生产类与现有 SceneFixtures 测试夹具。
将其放到 common/src/test/java/cc/sighs/gravityengine/gravity/collision/，
由 common 的 test source set 编译，再以包含 main/test classes 与依赖的 classpath 运行 main。
建议将场景改为 JUnit 回归断言，先看到旧代码失败，再实施修复。

A：已消费旋转 transport 仍可被 solver 选择；零位移请求走出虚假弧段。
B：跨查询边界的相交大型静态刚体被错误拒绝。
C：只证明 projector 与 carry 相加的数学双计数；尚未证明完整生产 travel 链触发，须增加跨 tick 集成测试。

common-tests-result.txt 为当前快照离线 251 项测试结果。
使用 Java 17、JUnit Console 1.10.3 / Jupiter 5.10.3、JOML 1.10.5；
未完成仓库正式 Gradle/JUnit 5.11.4 验证、target 构建或游戏运行验证。
